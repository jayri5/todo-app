from django.urls import path

from . import views


urlpatterns = [
    path('', views.index, name='index'),
    path('add', views.addTodo, name='add'),
    path('complete/<todo_id>', views.completeTodo, name='complete'),
    path('deletecomplete', views.deleteCompleted, name='deletecomplete'),
    path('deleteall', views.deleteAll, name='deleteall'),
    path('somepage.html', views.somepage, name='somepage.html'),
    path('somepage2.html', views.somepage2, name='somepage2.html'),
    path('addnote', views.addNote, name='addnote')
]
