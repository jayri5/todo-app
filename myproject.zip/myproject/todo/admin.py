from django.contrib import admin

from todo.models import Todo, Notes


admin.site.register(Todo)
admin.site.register(Notes)